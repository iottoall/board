#include <arduino.h>
#include <avr/sleep.h>
#include "iottoall.h"

#define PWR_EN 16
#define RTC_ADDR 0XA2
#define SOFT_SERIAL_TX 7
#define SOFT_SERIAL_RX 8

Iottoall::Iottoall():
    rtc(RTC_ADDR){
        mySerial = NULL;
}

void Iottoall::begin(){
    rtc.begin();
    rtc.now();
    DCEnable();
}

void Iottoall::sleepMin(int minutes){
    if(minutes < 1) return;
    unsigned long sec = minutes * 60 - 3;
    bool pwrEN = digitalRead(PWR_EN);
    DCDisable();
    byte adcsra = ADCSRA;          //save the ADC Control and Status Register A
    ADCSRA = 0;                    //disable the ADC

    //konfigurace Timer2 pro prijem hodinovych pulsu z RTC
    byte tccrA = TCCR2A;
    byte tccrB = TCCR2B;
    byte timsk = TIMSK2;
    byte tcnt = TCNT2;
    ASSR |= 1<<EXCLK;
    ASSR |= 1<<AS2;
    TCCR2A = 0;
    TIMSK2 = 0x01; //overflow interrupt
    if(sec < 256){
        TCCR2B = 0x01; //no divide
        TCNT2 = 256-sec;
    }else if(sec < 2048){
        TCCR2B = 0x02; // divide 8
        TCNT2 = 256 - (sec/8);
    }else if(sec < 8192){
        TCCR2B = 0x03; // divide 32
        TCNT2 = 256 - (sec/32);
    }else if(sec < 16384){
        TCCR2B = 0x04; // divide 64
        TCNT2 = 256 - (sec/64);
    }else if(sec < 32768){
        TCCR2B = 0x05; // divide 128
        TCNT2 = 256 - (sec/128);
    }else if(sec < 65536){
        TCCR2B = 0x06; // divide 256
        TCNT2 = 256 - (sec/256);
    }else if(sec < 262144){
        TCCR2B = 0x07; // divide 1024
        TCNT2 = 256 - (sec/1024);
    }else return;
    while(ASSR & 0x1F); //cekani nez se inicializuje asynchronni mod

    set_sleep_mode(SLEEP_MODE_PWR_SAVE);  
    cli();                         //stop interrupts to ensure the BOD timed sequence executes as required
    sleep_enable();
    sleep_bod_disable();           //for AVR-GCC 4.3.3 and later, this is equivalent to the previous 4 lines of code
    sei();                         //ensure interrupts enabled so we can wake up again
    sleep_cpu();  //go to sleep
     
    sleep_disable();               //wake up here
    ASSR = 0;
    while(ASSR & 0x1F);
    ADCSRA = adcsra; //restore ADCSRA
    TCCR2A = tccrA;
    TCCR2B = tccrB;
    TIMSK2 = timsk;
    TCNT2 = tcnt;

    if(pwrEN) DCEnable();
}

bool Iottoall::sigfoxSendMsg(String msg){
    if(!mySerial) DCEnable();
    String at = String("AT$SF=")+msg+"\r";
    mySerial->setTimeout(1000);
    mySerial->print(at);
    for(int i=0; i<20; i++){
        at = mySerial->readString();
        if(at != "") break;
    }
    return at.startsWith("OK");
}

String Iottoall::sigfoxSendAT(String ATcmd){
    if(!mySerial) DCEnable();
    mySerial->setTimeout(1000);
    mySerial->print(ATcmd+"\r");
    return mySerial->readString();
}


long Iottoall::getBatt(bool keepDCEnabled){
    if(!keepDCEnabled){
        DCDisable(); //disable DC/DC for occure measure
        delay(100);
    }
    
    ADMUX = bit(REFS0) | 14; // use VCC and internal bandgap
    delay(1);
    set_sleep_mode(SLEEP_MODE_ADC);
    sleep_enable(); 
    ADCSRA |= _BV (ADSC) | _BV (ADIE);
    sleep_mode();
    while (bit_is_set(ADCSRA, ADSC));
    int adc = ADC;
    sleep_disable();
    if(!keepDCEnabled) DCEnable();
    
    return (11*1024)/adc + 1;
}

void Iottoall::getBatt(long & batt, bool keepDCEnabled){
    batt = getBatt(keepDCEnabled);
}

void Iottoall::setTime(const DateTime & tm){
    rtc.adjust(tm);
}

DateTime Iottoall::getTime(){
    return rtc.now();
}

void Iottoall::getTime(DateTime & tm){
    tm = rtc.now();
}

//format example: "DD.MM.YYYY  hh:mm:ss"
String Iottoall::getTime(String format){
    DateTime now = rtc.now();
    int ln = format.length();
    char * buf = new char[ln+10];
    strncpy(buf, format.c_str(),ln);
    buf[ln] = 0;
    return now.format(buf);
}

void Iottoall::DCDisable(){
    delete mySerial;
    mySerial = NULL;
    pinMode(SOFT_SERIAL_TX, INPUT);
    digitalWrite(SOFT_SERIAL_TX, LOW); //disable pull-up
    digitalWrite(SOFT_SERIAL_RX, LOW); //disable pull-up
    digitalWrite(PWR_EN, LOW);
}

void Iottoall::DCEnable(){
    digitalWrite(PWR_EN, HIGH);
    mySerial = new SoftwareSerial(SOFT_SERIAL_RX, SOFT_SERIAL_TX);
    mySerial->begin(9600);
    delay(100);
}


// Watchdog Interrupt Service / is executed when  watchdog timed out
ISR(WDT_vect) { }

ISR(TIMER2_OVF_vect) { }

ISR(ADC_vect) { }

