#ifndef _IOTTOALL_H_
#define _IOTTOALL_H_

#include <SoftwareSerial.h>
#include "RTClib.h"

class Iottoall{
public:
    Iottoall();
    void begin();
    void sleepMin(int minutes);
    bool sigfoxSendMsg(String msg);
    String sigfoxSendAT(String ATcmd);
    long getBatt(bool keepDCEnabled = false);
    void getBatt(long & batt, bool keepDCEnabled = false);
    void setTime(const DateTime & tm);
    DateTime getTime();
    String getTime(String format);
    void getTime(DateTime & tm);
    void DCDisable();
    void DCEnable();
private:
    PCF8563 rtc;
    SoftwareSerial * mySerial;
};


#endif  //_IOTTOALL_H_