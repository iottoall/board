/*
 * Workaround dummy file to obtain the examples present in the IDE menu File->Examples
 */
