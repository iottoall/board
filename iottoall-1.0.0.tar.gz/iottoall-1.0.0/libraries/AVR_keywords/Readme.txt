The keywords.txt file contains all register and bit names for 
ATmega8535, ATmega16, ATmega32, ATmega164, ATmega324, ATmega644 and ATmega1284. 
The idea was to make Arduino IDE highlight these names, making it easier to read and write AVR code. 

In order to get this "library" working, you'll have to select a MightyCore compatible microcontroller and restart the IDE. Keywords will now be highlighted.